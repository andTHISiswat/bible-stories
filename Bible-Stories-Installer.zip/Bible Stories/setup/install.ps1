# Bible Stories installer: copies the app to this user's AppData, saves the pictures, and makes desktop + Start menu
# shortcuts. No admin rights needed. After this, it updates itself from GitHub each time it opens.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$src  = Join-Path $root 'app'
$dest = Join-Path $env:LOCALAPPDATA 'Bible Stories'
Write-Host ''
Write-Host '  Installing Bible Stories...'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
# keep a newer program that this PC already downloaded
$have = [int64]0; $bf = Join-Path $dest 'build.txt'
if (Test-Path $bf) { [int64]::TryParse((Get-Content $bf -TotalCount 1), [ref]$have) | Out-Null }
$mine = [int64](Get-Content (Join-Path $src 'build.txt') -TotalCount 1)
Get-ChildItem $src | ForEach-Object {
  if ($have -gt $mine -and ($_.Name -in @('Bible Stories.html', 'build.txt', 'pictures.csv'))) { return }
  Copy-Item $_.FullName -Destination $dest -Recurse -Force
}
foreach ($f in @('uninstall.ps1', 'open.ps1', 'launch.vbs', 'get-pictures.ps1')) { Copy-Item -Path (Join-Path $PSScriptRoot $f) -Destination $dest -Force }
Copy-Item -Path (Join-Path $root 'Uninstall Bible Stories.bat') -Destination $dest -Force
# reuse pictures from an earlier "Bible stories" folder on the desktop, if there is one
$desktop = [Environment]::GetFolderPath('Desktop')
$old = Join-Path $desktop 'Bible stories\pictures'
if (Test-Path $old) { Copy-Item (Join-Path $old '*') -Destination (Join-Path $dest 'pictures') -Recurse -Force -ErrorAction SilentlyContinue }
$ErrorActionPreference = 'Continue'
Write-Host '  Saving the Bible pictures so they work without internet (about 40 MB)...'
& (Join-Path $dest 'get-pictures.ps1') -Dir $dest
$ErrorActionPreference = 'Stop'
$ico = Join-Path $dest 'icon.ico'
$shell = New-Object -ComObject WScript.Shell
$menu  = [Environment]::GetFolderPath('Programs')
foreach ($lnk in @((Join-Path $desktop 'Bible Stories.lnk'), (Join-Path $menu 'Bible Stories.lnk'))) {
  $s = $shell.CreateShortcut($lnk)
  $s.TargetPath       = Join-Path $env:SystemRoot 'System32\wscript.exe'
  $s.Arguments        = '"' + (Join-Path $dest 'launch.vbs') + '"'
  $s.WorkingDirectory = $dest
  $s.IconLocation     = $ico + ',0'
  $s.Description      = 'One Bible story a night'
  $s.Save()
}
$u = $shell.CreateShortcut((Join-Path $menu 'Uninstall Bible Stories.lnk'))
$u.TargetPath = Join-Path $dest 'Uninstall Bible Stories.bat'
$u.WorkingDirectory = $dest
$u.IconLocation = $ico + ',0'
$u.Save()
Write-Host ''
Write-Host '  Done! Bible Stories is installed.'
Write-Host '  Open it with the Bible Stories icon on your desktop or in the Start menu.'
Write-Host '  From now on it updates itself each time it opens (when the PC is online).'
Write-Host ''
