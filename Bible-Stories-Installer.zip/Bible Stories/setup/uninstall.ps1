# Bible Stories uninstaller: removes the shortcuts and the installed program files.
$ErrorActionPreference = 'SilentlyContinue'
$dest    = Join-Path $env:LOCALAPPDATA 'Bible Stories'
$desktop = [Environment]::GetFolderPath('Desktop')
$menu    = [Environment]::GetFolderPath('Programs')
Remove-Item (Join-Path $desktop 'Bible Stories.lnk') -Force
Remove-Item (Join-Path $menu 'Bible Stories.lnk') -Force
Remove-Item (Join-Path $menu 'Uninstall Bible Stories.lnk') -Force
Write-Host ''
Write-Host '  Bible Stories has been removed from this PC.'
Write-Host ''
$cmd = '/c ping -n 6 127.0.0.1 >nul & rmdir /s /q "' + $dest + '"'
Start-Process -WindowStyle Hidden -FilePath 'cmd.exe' -ArgumentList $cmd
