@echo off
title Install Bible Stories
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup\install.ps1"
if errorlevel 1 goto manual
pause
exit /b 0

:manual
echo.
echo   The automatic install was blocked on this PC.
echo   You can still use Bible Stories:
echo     1. Copy the "app" folder to your Documents (or anywhere you like).
echo     2. Open "Bible Stories.html" in that folder (Edge or Chrome).
echo   (This way it won't update by itself or save the pictures.)
echo.
pause
